package com.example.ytnode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
